//
//  TestViewController.swift
//  LibsterApp
//
//  Created by Geo on 11/7/22.
//  Copyright © 2022 Geo. All rights reserved.
//

import UIKit
import Parse

class TestViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
//    func testParse2() {
//        let
//        User.username = "test_username"
//        User.password = "test_password"
//        User.email = "test_email@test.com"
//        User["userId"] = "A0000"
//        User["profilePicture"] = "url"
//        User["bio"] = "lorem ipsem"
//        User["borrowedBooks"] = []
//        User["bookmarkds"] = []
//        User["favorites"] = []
//        User["friends"] = []
//
//        User.signUpInBackground { (Success, Error) in
//            if (Success) {
//
//            }
//            else {
//                print("Error!")
//                print(Error)
//            }
//        }
        
    
 
        

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
