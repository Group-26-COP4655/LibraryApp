//
//  SignInViewController.swift
//  LibsterApp
//
//  Created by Geo on 11/14/22.
//  Copyright © 2022 Geo. All rights reserved.
//

import UIKit
import Parse
class SignInViewController: UIViewController {

    @IBOutlet weak var usernameField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func validateUsername() -> PFQuery<PFObject>{
        let query = PFQuery(className: "User")
        query.whereKey("username", equalTo: usernameField.text!)
        return query
    }
    func validatePassword() -> PFQuery<PFObject> {
        let query = PFQuery(className: "User")
        query.whereKey("password", equalTo: passwordField.text!)
        return query
    }
    @IBAction func onSignIn(_ sender: Any) {
        let username = validateUsername()
        let password = validatePassword()
        if username != nil && password != nil{
            performSegue(withIdentifier: "SignInSuccess", sender: nil)
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
