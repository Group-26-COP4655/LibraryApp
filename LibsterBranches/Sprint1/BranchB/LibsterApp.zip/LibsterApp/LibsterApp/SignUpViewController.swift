//
//  SignUpViewController.swift
//  LibsterApp
//
//  Created by Darwin Selles on 11/15/22.
//  Copyright © 2022 Geo. All rights reserved.
//

import UIKit
import Parse
import CryptoKit
import Alamofire
class SignUpViewController: UIViewController {

    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var verifyPasswordField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var verifyEmailField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func VerifyPassword()->Bool{
        if passwordField.text == verifyPasswordField.text{
            return true;
        }
        return false;
    }
    
    func VerifyEmail() -> Bool{
        if emailField.text == verifyEmailField.text{
            return true;
        }
        return false;
    }
    @IBAction func SignUpButton(_ sender: Any) {
        if(VerifyPassword() == false || VerifyEmail() == false)
        {
            print("Invalid")
        }
        else{
            var user = PFUser()
            user.username = usernameField.text
            user.password = passwordField.text
            user.email = passwordField.text
            user.signUpInBackground(){(success: Bool, error: Error?)->Void in
                if success{
                    self.performSegue(withIdentifier: "SignUpSuccess", sender: nil)
                    print("Success")
                }
                else{
                    print("FAil")
                }
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
